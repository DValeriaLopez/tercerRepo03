from setuptools import setup, find_packages

setup(
    name="tercerRepo03",                                    # Nombre del paquete
    version="0.1.0",                                        # Versión inicial
    packages=find_packages(),                               # Paquetes a incluir
    description="Un paquete pip simple de saludo",          # Breve descripción
    author="Valeria Lopez",                                 # Tu nombre
    author_email="DValeriaLopez@users.noreply.github",      # Tu correo electrónico
    url="https://github.com/DValeriaLopez/tercerRepo03",    # URL del proyecto
)